# The Data Directory

where your ingress and egress messages get stored, dont delete this directory